# AWS DevOps 訓練課程 - 內部分享
