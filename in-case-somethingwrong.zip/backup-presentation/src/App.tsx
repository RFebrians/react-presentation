// import idx from 'idx';
import * as React from 'react';
import { Impress, Step } from 'react-impressjs';
import 'react-impressjs/styles/react-impressjs.css';
import './App.css';
import firstimg from './static/firstimg.png';
import secondimg from './static/secondimg.png';
import thirdimg from './static/thirdimg.png';
import fourthimg from './static/fourthimg.png';
import fifthimg from './static/fifthimg.png';
import sixthimg from './static/sixthimg.png';
import seventhimg from './static/seventhimg.png';
import eightthimg from './static/eightthimg.png';
import ninthimg from './static/ninthimg.png';
import giphy from './static/giphy.gif'
import tenthimg from './static/tenthimg.png';
import eleventhimg from './static/eleventhimg.png';
import twelvethimg from './static/twelvethimg.png';
import thirteenthimg from './static/thirteenthimg.png';
import fourteenthimg from './static/fourteenthimg.png';
import fifteenthimg from './static/fifteenthimg.png';


class App extends React.Component<any, {
  // isMobile: boolean, isShowKH: boolean, isShowTP: boolean
}> {

  constructor(props: any) {
    super(props);
  }

  public render() {
    return (
      <div>
        <Impress hint={false} progress ={true} rootData={{ width: 512 }}>
          {/* React */}
          <Step>
            <div className="center" >
              <p style={{marginBottom: -50}}>Apa itu </p>
              <h1><b><span className="blue">React</span><span className="yellow">JS ?</span></b></h1>
            </div>
          </Step>
          {/* React Isi*/}
          <Step data={{x: -1700, y: 300 }}>
            <div className="center" >
              <div className="inline">
              <h4><b><span className="blue">React</span><span className="yellow">   adalah </span></b></h4>
              <p style={{marginBottom: -80}}>Javascript Library untuk membangun antar muka . </p>
            </div>
            </div>
          </Step>
          {/* Function or Class */}
          <Step data={{y: 500 }}>
            <div className="center">
              <div className="inline left line">
                <b className="blue">Prequisite</b>
                <p>React ditulis dalam JSX dan TSX </p>
              </div>
              <div className="inline right line">
                <b className="yellow">Target</b>
                <p>React dapat digunakan pada Framework , Package , bahkan Runtime</p>
              </div>
            </div>
          </Step>
          <Step data={{y: 1000 }}>
            <div className="center">
              <p><b>Hal ini membuat kreatifitas tanpa batasan dalam ide pengembangan dan karir </b> ✨✨ </p>
            </div>
          </Step>
          <Step data={{y: 1500 }}>
            <div className="center">
              <p><i>React begitu populer di kalangan Developer!<p> Anda tidak sendirian dalam membangun sebuah hal</p></i> <b>^_^</b></p>
            </div>
          </Step>
          {/* Image Class or Function */}
          <Step data={{x: 1000, y:500, rotateZ: 90, scale: 2 }}>
            <div className="center">
              <img src={giphy} alt="giphy"/>
            </div>
          </Step>

          {/* Hasil Comparison */}
          <Step data={{x: 2000, y: 1200, rotateZ: 180}}>
            <div className="center" >
              <p style={{marginBottom: -1}}>React dibuat untuk antarmuka</p>
              <p style={{marginBottom: -50}}>Tetapi tidak hanya antarmuka , dengan react website dapat menjadi fleksibel</p>
              <h1>
                <b>
                  <span className="blue">UI.</span>
                  <span className="red">UX.</span>
                  <span className="yellow">Logic</span>
                </b>
              </h1>
            </div>
          </Step>
          <Step data={{x: -1200, y:-800, z:-200, rotateY:-90, rotateZ: 90, scale: 1 }}>
            <div className="center">
              <div className="inline left line">
                <b className="blue">Prequisite</b>
                <p>React ditulis dalam JSX dan TSX </p>
              </div>
            </div>
          </Step>
          <Step data={{x: -1500, y:-200, z:-300, rotateY:-90, rotateZ: 90, scale: 1 }}>
            <div className="center">
              <div className="inline left line">
                <b className="blue">Prequisite</b>
                <p>React ditulis dalam JSX dan TSX </p>
              </div>
            </div>
          </Step>
          <Step data={{x: -1500, y:-600, z:-600, rotateY:-90, rotateZ: 90, scale: 1 }}>
            <div className="center">
              <div className="inline left line">
                <b className="blue">Prequisite</b>
                <p>React ditulis dalam JSX dan TSX </p>
              </div>
            </div>
          </Step>
          <Step data={{x: -1700, y:-800, z:-900, rotateY:-90, rotateZ: 90, scale: 1 }}>
            <div className="center">
              <div className="inline left line">
                <b className="blue">Prequisite</b>
                <p>React ditulis dalam JSX dan TSX </p>
              </div>
            </div>
          </Step>
          <Step data={{x: 2000, y: 700, rotateZ: 180}}>
            <div className="center">
              <div className="inline spare left line">
                <b className="blue">Routing</b>
                <p>Deskripsi</p>
              </div>
              <div className="inline">
                <b className="red">Hooks</b>
                <p>Deskripsi</p>
              </div>
              <div className="inline right line spare">
                <b className="yellow">Conditional Rendering</b>
                <p>Deskripsi</p>
              </div>
            </div>
          </Step>
          <Step data={{x: 2000, y: 200, rotateZ: 180}}>
            <div className="center">
              <div className="inline">
                <b>Skeleton 1</b>
                <p>Section 1</p>
                <div className="image-block">
                  <img src={thirteenthimg} alt="thirteenthimg"/>
                  <div>Skeleton 2</div>
                </div>
              </div>
              <div className="inline right line">
                <b>Skeleton2</b>
                <p>Section 2</p>
                <div className="inline">
                  <div className="inline image-block">
                    <img src={eleventhimg} alt="eleventhimg"/>
                    <div>Desc</div>
                  </div>
                  <div className="inline right image-block">
                    <img src={firstimg} alt="firstimg"/>
                    <div>Desc</div>
                  </div>
                  <div className="inline right image-block">
                    <img src={thirdimg} alt="thirdimg"/>
                    <div>Desc</div>
                  </div>
                </div>
              </div>
              <div className="inline right line">
                <b>Skeleton 3</b>
                <p>Section 3</p>
                <div className="inline">
                  <div className="inline image-block">
                    <img src={tenthimg} alt="tenthimg"/>
                    <div>Desc</div>
                  </div>
                  <div className="inline right image-block">
                    <img src={fourteenthimg} alt="fourteenthimg"/>
                    <div>Desc</div>
                  </div>
                </div>
              </div>
            </div>
          </Step>

          {/* CI */}
          <Step data={{x: 1000, y:-180, z: 200, rotateY:-90, rotateZ: 90, scale: 1 }}>
            <div className="center">
              <p><b className="big">90degree</b> Rotate</p>
            </div>
          </Step>
          <Step data={{x: 1000, y:-180, z: 100, rotateY:-90, rotateZ: 90, scale: 0.5 }}>
           <div className="center">
              <div className="inline">
                <b className="blue">Code</b>
                <div className="image-block">
                  <img src={sixthimg} alt="sixthimg"/>
                  <div>sixthimg</div>
                </div>
              </div>
              <div className="inline right left line">
                <b className="blue">Build</b>
                <div className="image-block">
                  <img src={fifthimg} alt="fifthimg"/>
                  <div>fifthimg</div>
                </div>
              </div>
              <div className="inline">
                <b className="blue">Test</b>
                <div className="image-block">
                  <img src={twelvethimg} alt="twelvethimg"/>
                  <div>twelvethimg</div>
                </div>
              </div>
            </div>
          </Step>

          {/* CD */}
          <Step data={{x: 1000, y:1380, z: 200, rotateY:-90, rotateZ: 90, scale: 1 }}>
            <div className="center">
              <p><b className="big">rotate</b> Continue</p>
            </div>
          </Step>
          <Step data={{x: 1000, y:1380, z: 100, rotateY:-90, rotateZ: 90, scale: 0.5 }}>
           <div className="center">
              <div className="inline">
                <b className="yellow">Skeleton</b>
                <div className="image-block">
                  <img src={seventhimg} alt="seventhimg"/>
                  <div>Skeleton</div>
                </div>
              </div>
              <div className="inline right line">
                <b className="yellow">Monitor</b>
                <div className="image-block">
                  <img src={fourthimg} alt="fourthimg"/>
                  <div>fourthimg</div>
                </div>
              </div>
            </div>
          </Step>

          {/* Code Pipeline */}
          <Step data={{x: 1000, y:3000, z: 100, rotateY:-90, rotateZ: 90 }}>
            <div className="center">
              <p><b className="big">CodeRotate</b></p>
              <div className="image-block">
                <img className="large" src={eightthimg} alt="eightthimg"/>
              </div>
            </div>
          </Step>
          <Step data={{x: 1000, y:3000, z: 100, rotateY:-180, rotateZ: 90 }}>
            <div className="center">
            <p><b className="big">CodeRotate</b></p>
              <div className="image-block">
                <img className="large" src={ninthimg} alt="ninthimg"/>
              </div>
            </div>
          </Step>

          {/* Infrastructure as Code */}
          <Step data={{x: 1000, y:4500, z: 100, rotateY:-180, rotateZ: 90 }}>
            <div className="center">
            <p><b className="big">Rotation</b> Code</p>
            <div className="inline">
                {/* <b className="blue">Code</b> */}
                <div className="image-block">
                  <img src={secondimg} alt="secondimg"/>
                  <div>Formation</div>
                </div>
              </div>
              <div className="inline right line">
                {/* <b className="blue">Build</b> */}
                <div className="image-block">
                  <img src={fifteenthimg} alt="fifteenthimg"/>
                  <div>Formation</div>
                </div>
              </div>
            </div>
          </Step>
          <Step data={{x: 1000, y:4000, z: 10000, rotateY:-180, rotateZ: 90 }} className="hide">
            <div className="center">
              <div className="inline left line">
                <b className="blue">skeleton</b>
                <p>description</p>
              </div>
              <div className="inline">
                <b className="red">skeleton</b>
                <p>description</p>
              </div>
              <div className="inline right line">
                <b className="yellow">skeleton</b>
                <p>description</p>
              </div>
            </div>
          </Step>

          <Step data={{x: 1000, y: 500, z: 3000, rotateY: 30 }} className="hide">
            <p>Coming <b>Soon</b>, 2021.</p>
          </Step>
        </Impress>
      </div>
    );
  }
}

export default App;
